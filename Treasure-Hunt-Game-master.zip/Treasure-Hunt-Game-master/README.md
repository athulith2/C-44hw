# Treasure-Hunt-Game
A small Treasure Hunt Game Program, built using C++
The objective of the Game is to move the cursor on the field in order to find the Treasure. 
But, beware of the Dragons Lurking in the Field. 
One can also get extra powers for the next chance, where your position gets doubled. 
